package Ejercicio1_Manual;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import Datos.DatosAgricultor;
import Soluciones.SolucionAgricultor;
import us.lsi.common.List2;
import us.lsi.common.Map2;

public class HuertosPD {

	public static record Spm(Integer a, Integer weight) implements Comparable<Spm> {
		public static Spm of(Integer a, Integer weight) {
			return new Spm(a, weight);
		}

		@Override
		public int compareTo(Spm sp) {
			return this.weight.compareTo(sp.weight);
		}
	}

	public static Map<HuertosProblem, Spm> memory;
	public static Integer mejorValor = Integer.MIN_VALUE;

	public static SolucionAgricultor search() {
		memory = Map2.empty();
		mejorValor = Integer.MIN_VALUE; // Estamos maximizando

		pdr_search(HuertosProblem.initial(), 0);
		return getSolucion();
	}

	private static Double acotar(Integer acum, HuertosProblem origen, Integer accion) {
		Integer weight = 0;
		if (accion != DatosAgricultor.getNumHuertos())
			weight = 1;
		if (accion != DatosAgricultor.getNumHuertos()) {
			weight = 1;
		}
		return acum + weight + origen.neighbor(accion).heuristic();
	}

	public static SolucionAgricultor getSolucion() {
		List<Integer> acciones = List2.empty();
		HuertosProblem prob = HuertosProblem.initial();
		Spm spm = memory.get(prob);
		while (spm != null && spm.a != null) {
			HuertosProblem old = prob;
			acciones.add(spm.a);
			prob = old.neighbor(spm.a);
			spm = memory.get(prob);
		}
		return SolucionAgricultor.of(acciones);
	}

	private static Spm pdr_search(HuertosProblem problema, Integer acumulado) {
		Boolean esGoal = HuertosProblem.goal().test(problema);
		if (memory.containsKey(problema)) {
			return memory.get(problema);
		}
		else if (esGoal) {
			Spm solucion_cb = Spm.of(null, 0);
			memory.put(problema, solucion_cb);
			if (acumulado > mejorValor) {
				mejorValor = acumulado;
			}
			return solucion_cb; 
		}
		// 3. En cualquier otro caso llamada recursiva
		else {
			List<Spm> solucionesPosibles = List2.empty();
			for (Integer action : problema.actions()) {
				Double estimacion = acotar(acumulado, problema, action);
				if (estimacion < mejorValor)
					continue;
				HuertosProblem vecino = problema.neighbor(action);
				Integer weight = 0;
				if (action != DatosAgricultor.getNumHuertos())
					weight = 1;
				Spm solucionVecino = pdr_search(vecino, acumulado + weight);
				if (solucionVecino != null) {
					Spm solucionBuena = Spm.of(action, solucionVecino.weight() + weight);
					solucionesPosibles.add(solucionBuena);
				}
			}
			// Busco la maxima porque estoy maximizando
			Spm mejorSolucion = solucionesPosibles.stream().max(Comparator.naturalOrder()).orElse(null);
			if (mejorSolucion != null) {
				memory.put(problema, mejorSolucion);
				return mejorSolucion;
			}
		}
		return null;
	}
}