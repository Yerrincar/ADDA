package Ejercicio1_Manual;

import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import Datos.DatosAgricultor;
import us.lsi.common.IntegerSet;
import us.lsi.common.List2;

public record HuertosProblem(Integer indice, List<IntegerSet> reparto, List<Integer> metrosDisponibles) {

    public static HuertosProblem initial() {
        List<Integer> metros = List2.empty();
        List<IntegerSet> reparto = List2.empty();
        for(int i = 0; i < DatosAgricultor.getNumHuertos(); i++) {
            metros.add(DatosAgricultor.getHuertoI(i));
            reparto.add(IntegerSet.empty());
        }
        return new HuertosProblem(0, reparto, metros);
    }
    
    public static Predicate<HuertosProblem> goal() {
        return obj -> obj.indice() == DatosAgricultor.getNumVariedades();
    }
    
    public static Predicate<HuertosProblem> goalHasSolution() {
        return obj -> true;
    }
    
    public List<Integer> actions() {
        List<Integer> alternativas = List2.of(DatosAgricultor.getNumHuertos());
        if(indice() >= DatosAgricultor.getNumVariedades()) {
            return List2.empty();
        } else {
            for(int i = 0; i<DatosAgricultor.getNumHuertos(); i++) {
                Set<Integer> huerto = reparto.get(i);
                Integer metrosRestantes = metrosDisponibles.get(i) - DatosAgricultor.getVariedadI(indice());
                if(metrosRestantes >= 0 && huerto.stream().noneMatch(x -> DatosAgricultor.getIncompatibilidad(x, indice()) == 1)) {
                    alternativas.add(i);
                }
            }
            return alternativas;
        }
    }
    
    public HuertosProblem neighbor(Integer a) {
        List<IntegerSet> repartoSiguiente = List2.copy(this.reparto);
        List<Integer> metrosDisponiblesSiguientes = List2.copy((this.metrosDisponibles));
        if(a < DatosAgricultor.getNumHuertos()) {
            Integer diferencia = metrosDisponibles().get(a) - DatosAgricultor.getVariedadI(this.indice);
            metrosDisponiblesSiguientes.set(a, diferencia);
            IntegerSet copiaHuerto = IntegerSet.copy(reparto.get(a));
            copiaHuerto.add(indice());
            repartoSiguiente.set(a, copiaHuerto);
        }
        return new HuertosProblem(this.indice + 1, repartoSiguiente, metrosDisponiblesSiguientes);
    }
    
    public Double heuristic() {
        return auxiliar(this, DatosAgricultor.getNumVariedades());
    }

    private static Double auxiliar(HuertosProblem vertice, Integer ultimoIndice){
        Double numVar = 0.;
        for(int i = vertice.indice(); i < ultimoIndice; i++) {
            for(int j = 0; j<DatosAgricultor.getNumHuertos(); j++) {
                Set<Integer> huerto = vertice.reparto().get(j);
                Integer metrosRestantes = vertice.metrosDisponibles().get(j) - DatosAgricultor.getVariedadI(i);
                Integer variedad = i;
                if(metrosRestantes >= 0 && huerto.stream().noneMatch(x -> DatosAgricultor.getIncompatibilidad(variedad, x) == 1)) {
                    numVar += 1;
                }
            }
        }
        return numVar;
    }
    
    public static void main(String[] args) {
        DatosAgricultor.iniDatos("ficheros/Ejercicio1DatosEntrada3.txt");
        System.out.println(initial());
    }
}