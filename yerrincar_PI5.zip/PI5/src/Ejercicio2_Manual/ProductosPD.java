package Ejercicio2_Manual;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import Datos.DatosProductos;
import Soluciones.SolucionProductos;
import us.lsi.common.List2;
import us.lsi.common.Map2;

public class ProductosPD {
    public static record SolucionParcial(Integer a, Integer weight) implements Comparable<SolucionParcial> {
        public static SolucionParcial of(Integer a, Integer weight) {
            return new SolucionParcial(a, weight);
        }

        @Override
        public int compareTo(SolucionParcial o) {
            return this.weight.compareTo(o.weight);
        }
    }

    public static Map<ProductosProblem, SolucionParcial> memoria;
    public static Integer mejorValor = Integer.MAX_VALUE;

    public static SolucionProductos search() {
        memoria = Map2.empty();
        mejorValor = Integer.MAX_VALUE;
        pdr_search(ProductosProblem.initial(), 0);
        return getSolucion();
    }

    private static SolucionProductos getSolucion() {
        List<Integer> acciones = List2.empty();
        ProductosProblem prob = ProductosProblem.initial();
        SolucionParcial spm = memoria.get(prob);
        while (spm != null && spm.a != null) {
            ProductosProblem old = prob;
            acciones.add(spm.a);
            prob = old.neighbor(spm.a);
            spm = memoria.get(prob);
        }
        return SolucionProductos.of(acciones);
    }

    public static Integer acotar(Integer acumulado, ProductosProblem origen, Integer action) {
        Integer weight = DatosProductos.getPrecioProducto(origen.indice()) * action;
        return (int) (acumulado + weight + origen.neighbor(action).heuristic());
    }

    private static SolucionParcial pdr_search(ProductosProblem problema, Integer acumulado) {
        if(memoria.containsKey(problema)) {
            return memoria.get(problema);
        }

        Boolean esGoal = ProductosProblem.goal().test(problema);
        Boolean esSolucion = ProductosProblem.goalHasSolution().test(problema);
        if(esGoal && esSolucion) {
            SolucionParcial solucion_cb = new SolucionParcial(null, 0);
            memoria.put(problema, solucion_cb);
            if(acumulado < mejorValor) {
                mejorValor = acumulado;
            }
            return solucion_cb;
        }

        List<SolucionParcial> solucionesPosibles = List2.empty();
        for(Integer action : problema.actions()) {
            Integer estimacion = acotar(acumulado, problema, action);
            if(estimacion > mejorValor) {
                continue;
            }
            ProductosProblem vecino = problema.neighbor(action);
            Integer weight = DatosProductos.getPrecioProducto(problema.indice()) * action;
            SolucionParcial solucionVecino = pdr_search(vecino, acumulado + weight);
            if(solucionVecino != null) {
                SolucionParcial solucionBuena = new SolucionParcial(action, solucionVecino.weight() + weight);
                solucionesPosibles.add(solucionBuena);
            }
        }

        SolucionParcial mejorSolucion = solucionesPosibles.stream().min(Comparator.naturalOrder()).orElse(null);
        if(mejorSolucion != null) {
            memoria.put(problema, mejorSolucion);
            return mejorSolucion;
        }
        return null;
    }
}