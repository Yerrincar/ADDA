package Ejercicio2_Manual;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import Datos.DatosProductos;
import us.lsi.common.IntegerSet;
import us.lsi.common.List2;

public record ProductosProblem(Integer indice, IntegerSet categoriasPorCubrir, List<Integer> presupuestoRestante,
		Integer acumValoracion) {
	public static ProductosProblem initial() {
		IntegerSet categorias =
		IntegerSet.of(DatosProductos.getProductos().stream()
		.map(obj -> obj.categoria())
		.collect(Collectors.toSet()));
		List<Integer> presupuesto = List2.empty();
		for(int i = 0; i < categorias.size(); i++) {
		presupuesto.add(DatosProductos.getPresupuesto());
		}
		return new ProductosProblem(0, categorias, presupuesto,
		0);
		}

	public static Predicate<ProductosProblem> goal() {
		return v -> v.indice() == DatosProductos.getNumProductos();
	}

	public static Predicate<ProductosProblem> goalHasSolution() {
		return v -> v.categoriasPorCubrir().isEmpty() && v.acumValoracion >= 0;
	}

	public List<Integer> actions() {
		if (indice == DatosProductos.getNumProductos()) {
			return List2.empty();
		} else {
			if (indice.equals(DatosProductos.getNumProductos() - 1)) {
				Integer valoracionFinal = acumValoracion + DatosProductos.getValoracionProducto(indice) - 3;
				if (valoracionFinal < 0 || categoriasPorCubrir.size() > 1) {
					return List2.of();
				} else if (presupuestoRestante.get(DatosProductos.getCategoria(indice))
						- DatosProductos.getPrecioProducto(indice) < 0) {
					return List2.of(0);
				} else if (categoriasPorCubrir.contains(DatosProductos.getCategoria(indice))) {
					return List2.of(1);
				} else {
					return List2.of(0, 1);
				}
			} else if (categoriasPorCubrir.isEmpty()
					|| presupuestoRestante.get(DatosProductos.getCategoria(indice))
							- DatosProductos.getPrecioProducto(indice) < 0) {
				return List2.of(0);
			} else {
				return List2.of(0, 1);
			}
		}
	}

	public Double heuristic() {
		if (this.categoriasPorCubrir().isEmpty())
			return 0.0;
		else
			return IntStream.range(this.indice(), DatosProductos.getNumProductos())
					.filter(x -> this.categoriasPorCubrir().contains(DatosProductos.getCategoria(x)))
					.mapToDouble(DatosProductos::getPrecioProducto).min().orElse(Double.MAX_VALUE);
	}

	public ProductosProblem neighbor(Integer a) {
		Integer i = indice() + 1;
		Integer acum = acumValoracion();
		IntegerSet categorias = categoriasPorCubrir().copy();
		List<Integer> presupuestos = new ArrayList<Integer>(presupuestoRestante());
		if (a == 1) {
			categorias.remove(DatosProductos.getCategoria(indice()));
			presupuestos.set(DatosProductos.getCategoria(indice()),
					presupuestos.get(DatosProductos.getCategoria(indice()))
							- DatosProductos.getPrecioProducto(indice()));
			acum = acumValoracion + DatosProductos.getValoracionProducto(indice) - 3;
		}
		return new ProductosProblem(i, categorias, presupuestos, acum);
	}
}