package Ejercicio2;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import Datos.DatosProductos;
import us.lsi.common.IntegerSet;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record ProductosVertex(Integer index, IntegerSet categoriasPorCubrir, List<Integer> presupuestoRestante,
		Integer acumValoracion) implements VirtualVertex<ProductosVertex, ProductosEdge, Integer> {

	public static ProductosVertex initial() {
		IntegerSet categorias = IntegerSet
				.of(DatosProductos.getProductos().stream().map(v -> v.categoria()).collect(Collectors.toSet()));
		List<Integer> presupuesto = List2.empty();
		for (int i = 0; i < categorias.size(); i++) {
			presupuesto.add(DatosProductos.getPresupuesto());
		}
		return new ProductosVertex(0, categorias, presupuesto, 0);

	}

	public static Predicate<ProductosVertex> goal() {
		return v -> v.index() == DatosProductos.getNumProductos();
	}

	public static Predicate<ProductosVertex> goalHasSolution() {
		return v -> v.categoriasPorCubrir.isEmpty() && v.acumValoracion >= 0;
	}

	@Override
	public List<Integer> actions() {
		if (index == DatosProductos.getNumProductos()) {
			return List2.empty();
		} else if ((categoriasPorCubrir.isEmpty() && acumValoracion >= 3)
				|| presupuestoRestante.get(DatosProductos.getCategoria(index))
						- DatosProductos.getPrecioProducto(index) < 0) {
			return List2.of(0);
		} else if (index == (DatosProductos.getNumProductos() - 1)) {
			Integer valoracionFinal = acumValoracion + (DatosProductos.getValoracionProducto(index) - 3);
			if (valoracionFinal < 0) {
				return List2.empty();
			} else if (categoriasPorCubrir.size() >= 2) {
				return List2.empty();
			} else if (presupuestoRestante.get(DatosProductos.getCategoria(index))
					- DatosProductos.getPrecioProducto(index) < 0) {
				return List2.of(0);
			} else if (categoriasPorCubrir.contains(DatosProductos.getCategoria(index))) {
				return List2.of(1);
			}
		}
		return List2.of(0, 1);
	}

	@Override
	public ProductosVertex neighbor(Integer a) {
		Integer j = index + 1;
		IntegerSet categorias = categoriasPorCubrir.copy();
		List<Integer> presupuesto = new ArrayList<Integer>(presupuestoRestante());
		Integer acum = acumValoracion;
		if (a == 1) {
			categorias.remove(DatosProductos.getCategoria(index));
			presupuesto.set(DatosProductos.getCategoria(index),
					presupuesto.get(DatosProductos.getCategoria(index))
							- DatosProductos.getPrecioProducto(index));
			acum = acumValoracion + DatosProductos.getValoracionProducto(index) - 3;
		}
		return new ProductosVertex(j, categorias, presupuesto, acum);
	}

	@Override
	public ProductosEdge edge(Integer a) {
		return ProductosEdge.of(this, neighbor(a), a);
	}

	public String toGraph() {
		return String.format("%s, %s, %s, %s", index(), this.categoriasPorCubrir.toString(),
				this.presupuestoRestante.toString(), this.acumValoracion.toString());
	}

}