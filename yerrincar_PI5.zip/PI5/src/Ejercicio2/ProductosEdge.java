
package Ejercicio2;

import Datos.DatosProductos;
import us.lsi.graphs.virtual.SimpleEdgeAction;

public record ProductosEdge(ProductosVertex source, ProductosVertex target, Integer action, Double weight)
		implements SimpleEdgeAction<ProductosVertex, Integer> {

	public static ProductosEdge of(ProductosVertex source, ProductosVertex target, Integer action) {
		Integer index = source.index();
		Double w = DatosProductos.getPrecioProducto(index) * action * 1.0;
		return new ProductosEdge(source, target, action, w);
	}

}