package Ejercicio2;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import Datos.DatosProductos;

public class ProductosHeuristic {

	public static Double heuristic(ProductosVertex v1, Predicate<ProductosVertex> goal, ProductosVertex v2) {
		if (v1.categoriasPorCubrir().isEmpty()) {
			return 0.;
		}
		Integer index = v1.index();
		return IntStream.range(index, DatosProductos.getNumProductos()).
				filter(i -> v1.categoriasPorCubrir().contains(DatosProductos.getCategoria(i))).
				mapToDouble(DatosProductos::getPrecioProducto).sum();
	}
}
