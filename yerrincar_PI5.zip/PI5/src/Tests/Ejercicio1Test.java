package Tests;

import java.util.List;
import java.util.Locale;

import org.jgrapht.GraphPath;

import Datos.DatosAgricultor;
import Ejercicio1.HuertosEdge;
import Ejercicio1.HuertosHeuristic;
import Ejercicio1.HuertosVertex;
import Soluciones.SolucionAgricultor;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.EGraph.Type;
import us.lsi.path.EGraphPath.PathType;

public class Ejercicio1Test {
	
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.of("en", "US"));
		
        for (int i = 1; i <= 3; i++) {
        	DatosAgricultor.iniDatos("Ficheros/Ejercicio1DatosEntrada" + i + ".txt");
        	System.out.println("\n\n>\tResultados para el test " + i + "\n");
        	
        	HuertosVertex start = HuertosVertex.initial();
        	
        	EGraph<HuertosVertex, HuertosEdge> grafo =
        			EGraph.virtual(start, HuertosVertex.goal(), PathType.Sum, Type.Max)
        			.edgeWeight(x -> x.weight())
        			.goalHasSolution(HuertosVertex.goalHasSolution())
        			.heuristic(HuertosHeuristic::heuristic)
        			.build();
        	
        	System.out.println("\n\n#### Ejercicio 1 Algoritmo A* ####");
        	
        	AStar<HuertosVertex, HuertosEdge, ?> astar = 
        			AStar.of(grafo);
        	
        	GraphPath<HuertosVertex, HuertosEdge> camino = 
        			astar.search().get();
        	
        	List<Integer> camino_as = 
        			camino.getEdgeList().stream()
        			.map(x -> x.action())
        			.toList();
        	
        	SolucionAgricultor sol = SolucionAgricultor.of(camino_as);
        	System.out.println(sol);
        	
        	GraphColors.toDot(astar.outGraph(),
        			"Grafos_Generados/Ejercicio1/Ejercicio1Auto" + i + ".gv",
        			v -> v.toGraph(),
        			e -> e.action().toString() + ", " + e.weight().toString(),
        			v -> GraphColors.colorIf(Color.green, HuertosVertex.goal().test(v)),
        			e -> GraphColors.colorIf(Color.green, (camino.getEdgeList().contains(e))));
        }
    }

}