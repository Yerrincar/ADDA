	package Tests;

import java.util.List;
import java.util.Locale;
import java.util.function.Predicate;

import org.jgrapht.GraphPath;

import Datos.DatosDistribuidor;
import Ejercicio3.DistribuidorEdge;
import Ejercicio3.DistribuidorHeuristic;
import Ejercicio3.DistribuidorVertex;
import Soluciones.SolucionDistribuidor;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.EGraph.Type;
import us.lsi.path.EGraphPath.PathType;

public class Ejercicio3Test {
	
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.of("en", "US"));
		
        for (int i = 1; i <= 3; i++) {
        	DatosDistribuidor.iniDatos("Ficheros/Ejercicio3DatosEntrada" + i + ".txt");
        	System.out.println("\n\n>\tResultados para el test " + i + "\n");
        	
        	DistribuidorVertex start = DistribuidorVertex.inicial();
        	Predicate<DistribuidorVertex> goal = DistribuidorVertex.goal();
        	
        	EGraph<DistribuidorVertex, DistribuidorEdge> grafo =
        			EGraph.virtual(start, goal, PathType.Sum, Type.Min)
        			.edgeWeight(x -> x.weight())
        			.goalHasSolution(DistribuidorVertex.goalHasSolution())
        			.heuristic(DistribuidorHeuristic::heuristic)
        			.build();
        	
        	System.out.println("\n\n#### Ejercicio 3 Algoritmo A* ####");
        	
        	AStar<DistribuidorVertex, DistribuidorEdge, ?> astar = 
        			AStar.of(grafo);
        	
        	GraphPath<DistribuidorVertex, DistribuidorEdge> camino = 
        			astar.search().get();
        	
        	List<Integer> camino_as = 
        			camino.getEdgeList().stream()
        			.map(x -> x.action())
        			.toList();
        	
        	SolucionDistribuidor sol = SolucionDistribuidor.of(camino_as);
        	System.out.println(sol);
        	
        	GraphColors.toDot(astar.outGraph(),
        			"Grafos_Generados/Ejercicio3/Ejercicio3Auto" + i + ".gv",
        			v -> v.toGraph(),
        			e -> e.action().toString() + ", " + e.weight().toString(),
        			v -> GraphColors.colorIf(Color.green, DistribuidorVertex.goal().test(v)),
        			e -> GraphColors.colorIf(Color.green, (camino.getEdgeList().contains(e))));
        }
    }

}