package Tests;

import java.util.List;
import java.util.Locale;

import org.jgrapht.GraphPath;

import Datos.DatosPersonas;
import Ejercicio4.PersonaEdge;
import Ejercicio4.PersonaHeuristic;
import Ejercicio4.PersonaVertex;
import Soluciones.SolucionPersonas;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.EGraph.Type;
import us.lsi.path.EGraphPath.PathType;

public class Ejercicio4Test {
public static void main(String[] args) {
		
		Locale.setDefault(Locale.of("en", "US"));
		
        for (int i = 1; i <= 3; i++) {
        	DatosPersonas.iniDatos("Ficheros/Ejercicio4DatosEntrada" + i + ".txt");
        	System.out.println("\n\n>\tResultados para el test " + i + "\n");
        	
        	PersonaVertex start = PersonaVertex.initial();
        	
        	EGraph<PersonaVertex, PersonaEdge> grafo =
        			EGraph.virtual(start, PersonaVertex.goal(), PathType.Sum, Type.Max)
        			.edgeWeight(x -> x.weight())
        			.goalHasSolution(PersonaVertex.goalHasSolution())
        			.heuristic(PersonaHeuristic::heuristic)
        			.build();
        	
        	System.out.println("\n\n#### Ejercicio 4 Algoritmo A* ####");
        	
        	AStar<PersonaVertex, PersonaEdge, ?> astar = 
        			AStar.of(grafo);
        	
        	GraphPath<PersonaVertex, PersonaEdge> camino = 
        			astar.search().get();
        	
        	List<Integer> camino_as = 
        			camino.getEdgeList().stream()
        			.map(x -> x.action())
        			.toList();
        	
        	SolucionPersonas sol = SolucionPersonas.of(camino_as);
        	System.out.println(sol);
        	
        	GraphColors.toDot(astar.outGraph(),
        			"Grafos_Generados/Ejercicio4/Ejercicio4Auto" + i + ".gv",
        			v -> v.toGraph(),
        			e -> e.action().toString() + ", " + e.weight().toString(),
        			v -> GraphColors.colorIf(Color.green, PersonaVertex.goal().test(v)),
        			e -> GraphColors.colorIf(Color.green, (camino.getEdgeList().contains(e))));
        }
    }


}
