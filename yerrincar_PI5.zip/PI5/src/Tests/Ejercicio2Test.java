package Tests;

import java.util.List;
import java.util.Locale;

import org.jgrapht.GraphPath;

import Datos.DatosProductos;
import Ejercicio2.ProductosEdge;
import Ejercicio2.ProductosHeuristic;
import Ejercicio2.ProductosVertex;
import Soluciones.SolucionProductos;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.EGraph.Type;
import us.lsi.path.EGraphPath.PathType;

public class Ejercicio2Test {
	
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.of("en", "US"));
		
        for (int i = 1; i <= 3; i++) {
        	DatosProductos.iniDatos("Ficheros/Ejercicio2DatosEntrada" + i + ".txt");
        	System.out.println("\n\n>\tResultados para el test " + i + "\n");
        	
        	ProductosVertex start = ProductosVertex.initial();
        	
        	EGraph<ProductosVertex, ProductosEdge> grafo =
        			EGraph.virtual(start, ProductosVertex.goal(), PathType.Sum, Type.Min)
        			.edgeWeight(x -> x.weight())
        			.goalHasSolution(ProductosVertex.goalHasSolution())
        			.heuristic(ProductosHeuristic::heuristic)
        			.build();
        	
        	System.out.println("\n\n#### Ejercicio 2 Algoritmo A* ####");
        	
        	AStar<ProductosVertex, ProductosEdge, ?> astar = 
        			AStar.of(grafo);
        	
        	GraphPath<ProductosVertex, ProductosEdge> camino = 
        			astar.search().get();
        	
        	List<Integer> camino_as = 
        			camino.getEdgeList().stream()
        			.map(x -> x.action())
        			.toList();
        	
        	SolucionProductos sol = SolucionProductos.of(camino_as);
        	System.out.println(sol);
        	
        	GraphColors.toDot(astar.outGraph(),
        			"Grafos_Generados/Ejercicio2/Ejercicio2Auto" + i + ".gv",
        			v -> v.toGraph(),
        			e -> e.action().toString() + ", " + e.weight().toString(),
        			v -> GraphColors.colorIf(Color.green, ProductosVertex.goal().test(v)),
        			e -> GraphColors.colorIf(Color.green, (camino.getEdgeList().contains(e))));
        }
    }

}