package Ejercicio3;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import Datos.DatosDistribuidor;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record DistribuidorVertex(Integer z, List<Integer> unidadesRestantes, List<Integer> demandasRestantes)
        implements VirtualVertex<DistribuidorVertex, DistribuidorEdge, Integer> {

    public static DistribuidorVertex of(Integer z, List<Integer> unidadesRestantes, List<Integer> demandasRestantes) {
        return new DistribuidorVertex(z, unidadesRestantes, demandasRestantes);
    }

    public static DistribuidorVertex inicial() {
        List<Integer> unidadesIniciales = new ArrayList<>();
        List<Integer> demandasIniciales = new ArrayList<>();
        for(int i = 0; i<DatosDistribuidor.getNumProductos(); i++) {
            unidadesIniciales.add(DatosDistribuidor.getUnidad(i));
        }
        for(int j = 0; j<DatosDistribuidor.getNumDestinos(); j++) {
            demandasIniciales.add(DatosDistribuidor.getDemanda(j));
        }
        return of(0, unidadesIniciales, demandasIniciales);
    }

    public static Predicate<DistribuidorVertex> goal(){
        return x -> x.z() == DatosDistribuidor.getNumDestinos()*DatosDistribuidor.getNumProductos();
    }

    public static Predicate<DistribuidorVertex> goalHasSolution() {
        return x-> x.demandasRestantes().stream().allMatch(y -> y == 0);
    }

    @Override
    public List<Integer> actions() {
        List<Integer> alternativas = new ArrayList<>();
        Integer numVariables = DatosDistribuidor.getNumProductos() * DatosDistribuidor.getNumDestinos();
        if(z() >= numVariables) {
            return alternativas;
        }
        else {
            Integer indiceDestino = z()%DatosDistribuidor.getNumDestinos();
            Integer indiceProducto = z()/DatosDistribuidor.getNumDestinos();
            Integer uniRes = unidadesRestantes().get(indiceProducto);
            Integer demRes = demandasRestantes().get(indiceDestino);
            if(demRes == 0 || uniRes == 0) {
                alternativas = List2.of(0);
            }
            else if(uniRes < 0) {
                return List2.empty();
            }
            else if(uniRes < demRes) {
                alternativas = List2.of(0, uniRes);
            } else {
                alternativas = List2.of(0, demRes);
            }
            return alternativas;
        }
    }

    @Override
    public DistribuidorVertex neighbor(Integer a) {
        Integer i = z() / DatosDistribuidor.getNumDestinos();
        Integer j = z() % DatosDistribuidor.getNumDestinos();

        List<Integer> unidadesRAct = new ArrayList<>(unidadesRestantes());
        List<Integer> demandasRAct = new ArrayList<>(demandasRestantes());

        Integer indiceProducto = i;
        Integer indiceDestino = j;

        unidadesRAct.set(indiceProducto, unidadesRAct.get(indiceProducto) - a);
        demandasRAct.set(indiceDestino, demandasRAct.get(indiceDestino) - a);

        return of(z() + 1, unidadesRAct, demandasRAct);
    }

    @Override
    public DistribuidorEdge edge(Integer a) {
        return DistribuidorEdge.of(this, neighbor(a), a);
    }

    public String toGraph() {
        return String.format("%d; %s; %s", this.z, this.unidadesRestantes, this.demandasRestantes);
    }
}