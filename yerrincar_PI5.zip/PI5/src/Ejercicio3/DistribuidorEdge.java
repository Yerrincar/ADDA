package Ejercicio3;

import Datos.DatosDistribuidor;
import us.lsi.graphs.virtual.SimpleEdgeAction;

public record DistribuidorEdge(DistribuidorVertex source, DistribuidorVertex target, Integer action, Double weight)
		implements SimpleEdgeAction<DistribuidorVertex, Integer> {
	public static DistribuidorEdge of(DistribuidorVertex origen, DistribuidorVertex destino, Integer accion) {
		Integer pro = origen.z() / DatosDistribuidor.getNumDestinos();
		Integer des = origen.z() % DatosDistribuidor.getNumDestinos();
		Double w = DatosDistribuidor.getCoste(pro, des) * accion * 1.0;
		return new DistribuidorEdge(origen, destino, accion, w);
	}
}
