package Ejercicio3;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import Datos.DatosDistribuidor;

public class DistribuidorHeuristic {
	public static Double heuristic(DistribuidorVertex v1, Predicate<DistribuidorVertex> goal, DistribuidorVertex v2) {
		if (v1.demandasRestantes().stream().allMatch(x -> x <= 0))
			return 0.;
		Integer ultimoIndice = DatosDistribuidor.getNumDestinos() * DatosDistribuidor.getNumProductos();
		return IntStream.range(v1.z(), ultimoIndice)
				.filter(i -> v1.demandasRestantes().get(i % DatosDistribuidor.getNumDestinos()) > 0)
				.mapToDouble(i -> DatosDistribuidor.getCoste(i / DatosDistribuidor.getNumDestinos(),
						i % DatosDistribuidor.getNumDestinos()))
				.min().orElse(Double.MAX_VALUE);
	}

}
