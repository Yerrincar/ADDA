package Tests_Manuales;

import Datos.DatosDistribuidor;
import Ejercicio3_Manual.DistribuidorBT;

public class Ejercicio3_Test_Manual {
	public static void main(String[] args) {
// TODO Auto-generated method stub
		System.out.println("######## Ejercicio 3 Manual########");
		for (Integer id_fichero = 1; id_fichero <= 3; id_fichero++) {
			DatosDistribuidor.iniDatos("Ficheros/Ejercicio3DatosEntrada" + id_fichero + ".txt");
			System.out.println("\n\n>\tResultados para eltest " + id_fichero + "\n");
			DistribuidorBT.search();
			System.out.println(DistribuidorBT.getSolucion() + "\n");
		}
	}
}
