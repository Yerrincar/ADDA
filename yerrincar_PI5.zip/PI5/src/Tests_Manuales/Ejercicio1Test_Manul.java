	package Tests_Manuales;

import java.util.List;

import Datos.DatosAgricultor;
import Ejercicio1_Manual.HuertosPD;
import us.lsi.common.String2;

public class Ejercicio1Test_Manul {
	public static void main(String[] args) {
		List.of(1,2,3).forEach(num_test -> {
			System.out.println("*************************************************FICHERO " + num_test + "******************************************");
			DatosAgricultor.iniDatos("Ficheros/Ejercicio1DatosEntrada"+num_test+".txt");
			String2.toConsole("Solucion del ejercicio 1 usando programacion dinamica manual para el fichero %s: %s\n", num_test, HuertosPD.search());
		});
	}

}
