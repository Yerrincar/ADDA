package Tests_Manuales;

import Datos.DatosPersonas;
import Ejercicio4_Manual.PersonaBT;

public class Ejercicio4_Test_Manual {
	public static void main(String[] args) {
// TODO Auto-generated method stub
		System.out.println("######## Ejercicio 4 Manual########");
		for (Integer id_fichero = 1; id_fichero <= 3; id_fichero++) {
			DatosPersonas.iniDatos("Ficheros/Ejercicio4DatosEntrada" + id_fichero + ".txt");
			System.out.println("\n\n>\tResultados para eltest " + id_fichero + "\n");
			PersonaBT.search();
			System.out.println(PersonaBT.getSolucion() + "\n");
		}
	}
}
