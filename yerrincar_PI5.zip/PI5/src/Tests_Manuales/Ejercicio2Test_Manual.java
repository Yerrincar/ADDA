package Tests_Manuales;

import java.util.List;

import Datos.DatosProductos;
import Ejercicio2_Manual.ProductosPD;
import us.lsi.common.String2;

public class Ejercicio2Test_Manual {
	public static void main(String[] args) {
		List.of(1,2,3).forEach(num_test -> {
			System.out.println("*************************************************FICHERO " + num_test + "******************************************");
			DatosProductos.iniDatos("Ficheros/Ejercicio2DatosEntrada"+num_test+".txt");
			String2.toConsole("Solucion del ejercicio 2 usando programacion dinamica manual para el fichero %s: %s\n", num_test, ProductosPD.search());
		});
	}

}
