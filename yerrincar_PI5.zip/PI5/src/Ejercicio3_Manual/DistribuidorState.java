package Ejercicio3_Manual;

import java.util.List;

import Datos.DatosDistribuidor;
import Soluciones.SolucionDistribuidor;
import us.lsi.common.List2;

public class DistribuidorState {
    DistribuidorProblem actual;
    Double acumulado;
    List<Integer> acciones;
    List<DistribuidorProblem> anteriores;

    private DistribuidorState(DistribuidorProblem problema, Double acum, List<Integer> lisA, List<DistribuidorProblem> lisP) {
        actual = problema;
        acumulado = acum;
        acciones = lisA;
        anteriores = lisP;
    }

    public static DistribuidorState of(DistribuidorProblem problema, Double acum, List<Integer> lisA, List<DistribuidorProblem> lisP) {
        return new DistribuidorState(problema, acum, lisA, lisP);
    }

    public static DistribuidorState initial() {
        DistribuidorProblem inicio = DistribuidorProblem.initial();
        return of(inicio, 0., List2.empty(), List2.empty());
    }

    public void forward(Integer a) {
        acumulado += a * DatosDistribuidor.getCoste(actual.z() / DatosDistribuidor.getNumDestinos(), actual.z() % DatosDistribuidor.getNumDestinos());
        acciones.add(a);
        anteriores.add(actual);
        actual = actual.neighbor(a);
    }

    public void back() {
        int ultimo = acciones.size() - 1;
        var problemaAnterior = anteriores.get(ultimo);
        acumulado -= acciones.get(ultimo) * DatosDistribuidor.getCoste(problemaAnterior.z() / DatosDistribuidor.getNumDestinos(), problemaAnterior.z() % DatosDistribuidor.getNumDestinos());
        acciones.remove(ultimo);
        anteriores.remove(ultimo);
        actual = problemaAnterior;
    }

    public List<Integer> alternativas(){
        return actual.actions();
    }

    public Double cota(Integer a) {
        Double weight = a * DatosDistribuidor.getCoste(actual.z() / DatosDistribuidor.getNumDestinos(), actual.z() % DatosDistribuidor.getNumDestinos()) * 1.;
        return acumulado + weight + actual.neighbor(a).heuristic();
    }

    public Boolean esTerminal() {
        return DistribuidorProblem.goal().test(actual);
    }

    public Boolean esSolucion() {
        return DistribuidorProblem.goalHasSolution().test(actual);
    }

    public SolucionDistribuidor getSolucion() {
        return SolucionDistribuidor.of(acciones);
    }
}