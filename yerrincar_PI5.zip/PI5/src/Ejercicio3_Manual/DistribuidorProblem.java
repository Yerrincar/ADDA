package Ejercicio3_Manual;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import Datos.DatosDistribuidor;
import us.lsi.common.List2;

public record DistribuidorProblem(Integer z, List<Integer> unidadesRestantes, List<Integer> demandasRestantes) {
    public static DistribuidorProblem initial() {
        List<Integer> uniRes = DatosDistribuidor.getProductos()
                .stream()
                .map(pro -> pro.unidades())
                .toList();
        List<Integer> demRes = DatosDistribuidor.getDestinos()
                .stream()
                .map(des -> des.demandaMinima())
                .toList();
        return new DistribuidorProblem(0, uniRes, demRes);
    }

    public static Predicate<DistribuidorProblem> goal(){
        return obj -> obj.z == DatosDistribuidor.getNumProductos() * DatosDistribuidor.getNumDestinos();
    }

    public static Predicate<DistribuidorProblem> goalHasSolution(){
        return obj -> obj.demandasRestantes().stream().allMatch(x -> x <= 0);
    }

    public List<Integer> actions() {
        List<Integer> alternativas = new ArrayList<>();
        Integer numVariables = DatosDistribuidor.getNumProductos() * DatosDistribuidor.getNumDestinos();
        if(this.z >= numVariables) {
            return alternativas;
        }
        else {
            Integer indiceDestino = this.z % DatosDistribuidor.getNumDestinos();
            Integer indiceProducto = this.z / DatosDistribuidor.getNumDestinos();
            Integer uniRes = this.unidadesRestantes.get(indiceProducto);
            Integer demRes = this.demandasRestantes.get(indiceDestino);
            if(demRes == 0 || uniRes == 0) {
                alternativas = List2.of(0);
            }
            else if(uniRes < 0) {
                return List2.empty();
            }
            else if(uniRes < demRes) {
                alternativas = List2.rangeList(0, uniRes + 1);
            } else {
                alternativas = List2.rangeList(0, demRes + 1);
            }
            return alternativas;
        }
    }

    public DistribuidorProblem neighbor(Integer a) {
        Integer index = this.z + 1;
        List<Integer> unidades = List2.copy(this.unidadesRestantes);
        List<Integer> demandas = List2.copy(this.demandasRestantes);
        unidades.set(this.z / DatosDistribuidor.getNumDestinos(), unidades.get(this.z / DatosDistribuidor.getNumDestinos()) - a);
        demandas.set(this.z % DatosDistribuidor.getNumDestinos(), demandas.get(this.z % DatosDistribuidor.getNumDestinos()) - a);
        return new DistribuidorProblem(index, unidades, demandas);
    }

    public Double heuristic() {
        if(this.demandasRestantes().stream().allMatch(x -> x <= 0)) return 0.;
        else {
            Integer ultimoIndice = DatosDistribuidor.getNumDestinos() * DatosDistribuidor.getNumProductos();
            return IntStream.range(this.z(), ultimoIndice)
                    .mapToDouble(i -> DatosDistribuidor.getCoste(i / DatosDistribuidor.getNumDestinos(), i % DatosDistribuidor.getNumDestinos()))
                    .min()
                    .orElse(Double.MAX_VALUE);
        }
    }

    public static void main(String[] args) {
        DatosDistribuidor.iniDatos("ficheros/Ejercicio3DatosEntrada1.txt");
        System.out.println(initial());
    }
}