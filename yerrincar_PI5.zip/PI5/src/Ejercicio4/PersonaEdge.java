package Ejercicio4;

import Datos.DatosPersonas;
import us.lsi.graphs.virtual.SimpleEdgeAction;

public record PersonaEdge(PersonaVertex source, PersonaVertex target, Integer action, Double weight)
		implements SimpleEdgeAction<PersonaVertex, Integer> {
	public static PersonaEdge of(PersonaVertex v1, PersonaVertex v2, Integer action) {
		Double w = 0.;
		if (v1.index() % 2 == 1)
			w = DatosPersonas.getAfinidad(v1.ultima(), action) * 1.0;
		return new PersonaEdge(v1, v2, action, w);
	}
}
