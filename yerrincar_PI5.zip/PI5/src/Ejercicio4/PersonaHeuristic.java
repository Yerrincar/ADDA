package Ejercicio4;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import Datos.DatosPersonas;

public class PersonaHeuristic {
	public static Double heuristic(PersonaVertex v1, Predicate<PersonaVertex> goal, PersonaVertex v2) {
	    if(v1.ultima() == DatosPersonas.getNumPersonas())
	        return 0.;
	    else 
	        return IntStream.range(v1.ultima(), DatosPersonas.getNumPersonas())
	            .mapToDouble(i -> mejorOpcion(i, v1.restante().stream().toList())).sum();
	}

	private static Double mejorOpcion(Integer i, List<Integer> restante) {
	    return restante.stream()
	        .filter(j -> !j.equals(i))
	        .mapToDouble(j -> DatosPersonas.getAfinidad(i, j)).max()
	        .orElse(0);
	}

}
