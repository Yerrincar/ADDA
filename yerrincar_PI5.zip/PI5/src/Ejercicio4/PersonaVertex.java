package Ejercicio4;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import Datos.DatosPersonas;
import us.lsi.common.List2;
import us.lsi.common.Set2;
import us.lsi.graphs.virtual.VirtualVertex;

public record PersonaVertex(Integer index, Set<Integer> restante, Integer ultima) implements VirtualVertex<PersonaVertex, PersonaEdge, Integer> {
    public static PersonaVertex initial() {
        Set<Integer> restante = Set2.of();
        for(int i = 0; i < DatosPersonas.getNumPersonas(); i++) {
            restante.add(i);
        }
        return new PersonaVertex(0, restante, DatosPersonas.getNumPersonas());
    }

    public static Predicate<PersonaVertex> goal(){
        return obj -> obj.index() == DatosPersonas.getNumPersonas();
    }

    public static Predicate<PersonaVertex> goalHasSolution(){
        return obj -> true;
    }

    @Override
    public List<Integer> actions() {
        List<Integer> alternativas = new ArrayList<>();
        if(index() == DatosPersonas.getNumPersonas()) {
            return List2.empty();
        } else if(index() % 2 == 1) {
            Set<String> idiomasPersona = DatosPersonas.getIdiomas(this.ultima);
            Integer edadPersona = DatosPersonas.getEdad(this.ultima);
            String nacionPersona = DatosPersonas.getNacionalidad(this.ultima);
            for(Integer pareja : this.restante) {
                Set<String> idiomasPareja = DatosPersonas.getIdiomas(pareja);
                Integer edadPareja = DatosPersonas.getEdad(pareja);
                String nacionPareja = DatosPersonas.getNacionalidad(pareja);
                Boolean idiomaEnComun = idiomasPareja.stream().anyMatch(idioma -> idiomasPersona.contains(idioma));
                Integer diferenciaEdad = Math.abs(edadPersona - edadPareja);
                Boolean distintaNacionalidad = !nacionPersona.equals(nacionPareja);
                if(idiomaEnComun && diferenciaEdad <= 5 && distintaNacionalidad) {
                    alternativas.add(pareja);
                }
            }
            return alternativas;
        } else {
            return List2.of(this.restante.stream().findFirst().get());
        }
    }

    @Override
    public PersonaVertex neighbor(Integer a) {
        Integer index = this.index + 1;
        Set<Integer> res = Set2.copy(this.restante);
        if(index % 2 == 0) {
            Integer ult = DatosPersonas.getNumPersonas();
            res.remove(a);
            return new PersonaVertex(index, res, ult);
        } else {
            Integer ult = a;
            res.remove(ult);
            return new PersonaVertex(index, res, ult);
        }
    }

    @Override
    public PersonaEdge edge(Integer a) {
        return PersonaEdge.of(this, this.neighbor(a), a);
    }

    public String toGraph() {
        return this.index() + ", " + this.restante() + ", " + this.ultima();
    }

    public static void main(String[] args) {
        DatosPersonas.iniDatos("Ficheros/Ejercicio4DatosEntrada1.txt");
        System.out.println(String.valueOf(initial()));
    }
}