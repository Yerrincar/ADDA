package Datos;

import java.util.List;
import java.util.Set;

import us.lsi.common.Files2;
import us.lsi.common.Set2;

public class DatosPersonas {
    public static List<Persona> personas;

    public record Persona(Integer codigo, Integer edad, Set<String> idiomas, String nacionalidad, Set<Afinidad> afinidades) {
        public static Persona create(String s) {
            String[] s1 = s.split(";");
            String[] s2 = s1[0].trim().split(" -> edad=");
            Integer codigo = Integer.valueOf(s2[0].trim().replace("P", ""));
            Integer edad = Integer.valueOf(s2[1].trim());
            String nacionalidad = s1[2].trim().replace("nacionalidad=", "");
            String idiomasStr = s1[1].trim().replace("idiomas=", "").replace("(", "").replace(")", "");
            Set<String> idiomas = Set2.parse(idiomasStr, ",", String::valueOf);
            String[] afinidadStr = s1[3].trim().split("afinidades=");
            Set<Afinidad> afinidades = Set2.parse(afinidadStr[1], ",", Afinidad::create);
            return new Persona(codigo, edad, idiomas, nacionalidad, afinidades);
        }
    }

    public record Afinidad(Integer persona, Integer afinidad) {
        public static Afinidad create(String s) {
            String[] s1 = s.replace("(", "").replace(")", "").split(":");
            Integer persona = Integer.valueOf(s1[0].trim());
            Integer afinidad = Integer.valueOf(s1[1].trim());
            return new Afinidad(persona, afinidad);
        }
    }

    public static List<Persona> getPersonas() {
        return personas;
    }

    public static Integer getNumPersonas() {
        return personas.size();
    }

    public static Set<String> getIdiomas(Integer i) {
        return personas.stream().filter(p -> p.codigo.equals(i)).findFirst().map(Persona::idiomas).get();
    }

    public static Integer getEdad(Integer i) {
        return personas.stream().filter(p -> p.codigo.equals(i)).findFirst().map(Persona::edad).get();
    }

    public static String getNacionalidad(Integer i) {
        return personas.stream().filter(p -> p.codigo.equals(i)).findFirst().map(Persona::nacionalidad).get();
    }

    public static Integer getAfinidad(Integer i, Integer j) {
        return personas.stream().filter(p -> p.codigo.equals(i)).findFirst().map(Persona::afinidades).get().stream().filter(p -> p.persona.equals(j)).findFirst().map(Afinidad::afinidad).get();
    }

    public static void iniDatos(String fichero) {
        personas = Files2.streamFromFile(fichero).filter(x-> x.contains("nacionalidad")).map(Persona::create).toList();
    }
}