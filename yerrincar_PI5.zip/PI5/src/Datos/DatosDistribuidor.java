package Datos;

import java.util.List;

import us.lsi.common.Files2;
import us.lsi.common.List2;

public class DatosDistribuidor {
	public static List<Destino> destinos;
	public static List<Producto> productos;

	public record Destino(Integer codigo, Integer demandaMinima) {
		public static Destino create(String s) {
			String[] s1 = s.split(";");
			String[] d = s1[0].trim().split(": demandaminima=");

			Integer codigo = Integer.valueOf(d[0].trim().replace("D", ""));
			Integer demandaMinima = Integer.valueOf(d[1].trim());
			return new Destino(codigo, demandaMinima);
		}
	}

	public record Producto(Integer codigo, Integer unidades, List<Coste> costes) {
		public static Producto create(String s) {
			String[] s1 = s.split(";");
			String[] s2 = s1[0].trim().split(" -> uds=");
			Integer codigo = Integer.valueOf(s2[0].trim().replace("P", ""));
			Integer unidades = Integer.valueOf(s2[1].trim());
			String[] costeStr = s1[1].trim().split("coste_almacenamiento=");
			List<Coste> costes = List2.parse(costeStr[1], ",", Coste::create);

			return new Producto(codigo, unidades, costes);
		}
	}

	public record Coste(Integer destino, Integer coste) {
		public static Coste create(String s) {
			String[] s1 = s.replace("(", "").replace(")", "").split(":");
			Integer destino = Integer.valueOf(s1[0].trim());
			Integer coste = Integer.valueOf(s1[1].trim());
			return new Coste(destino, coste);
		}
	}

	public static void iniDatos(String fichero) {
		destinos = Files2.streamFromFile(fichero).filter(x -> x.contains("demandaminima")).map(Destino::create)
				.toList();
		productos = Files2.streamFromFile(fichero).filter(x -> x.contains(" -> uds=")).map(Producto::create).toList();
	}

	public static void main(String[] args) {
		iniDatos("ficheros/Ejercicio3DatosEntrada3.txt");
	}

	public static List<Destino> getDestinos() {
		return destinos;
	}

	public static List<Coste> getCostes(Integer i) {
		return productos.get(i).costes();
	}

	public static List<Producto> getProductos() {
		return productos;
	}

	public static Integer getNumProductos() {
		return productos.size();
	}

	public static Integer getNumDestinos() {
		return destinos.size();
	}

	public static Integer getDemanda(Integer i) {
		return destinos.get(i).demandaMinima();
	}

	public static List<Integer> getUnidades() {
		return productos.stream().map(Producto::unidades).toList();
	}

	public static Integer getUnidades(Integer i) {
		return productos.get(i).unidades();
	}

	public static List<Integer> getDemandas() {
		return destinos.stream().map(Destino::demandaMinima).toList();
	}

	public static Integer getCoste(Integer i, Integer j) {
		return productos.get(i).costes().get(j).coste();
	}

	public static Integer getUnidad(Integer i) {
        return productos.get(i).unidades();
    
	}
}