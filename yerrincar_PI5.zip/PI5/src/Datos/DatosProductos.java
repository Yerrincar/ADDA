package Datos;

import java.util.List;
import java.util.stream.Collectors;

import us.lsi.common.Files2;
import us.lsi.common.String2;

public class DatosProductos {
	public static Integer presupuesto;
	public static List<Producto> productos;

	public record Producto(Integer id, Integer precio, Integer categoria, Integer valoracion) {
		public static Producto create(String s) {
			String[] productos = s.split(":");
			Integer id = Integer.valueOf(productos[0].trim());
			Integer precio = Integer.valueOf(productos[1].trim());
			Integer categoria = Integer.valueOf(productos[2].trim());
			Integer valoracion = Integer.valueOf(productos[3].trim());
			return new Producto(id, precio, categoria, valoracion);
		}

		public String toString() {
			return "Producto: " + id + ", Precio: " + precio + ", Categoria: " + categoria + ", Valoracion: "
					+ valoracion;
		}
	}

	public static Integer getPresupuesto() {
		return presupuesto;
	}

	public static List<Producto> getProductos() {
		return productos;
	}

	public static Integer getNumProductos() {
		return productos.size();
	}

	public static Integer getM() {
		return (int) productos.stream().map(p -> p.categoria()).distinct().count();
	}

	public static Integer getCategoria(Integer i, Integer j) {
		return productos.get(i).categoria().equals(j) ? 1 : 0;
	}

	public static Integer getCategoria(Integer i) {
		return productos.get(i).categoria();
	}

	public static Integer getPrecioProducto(Integer i) {
		return productos.get(i).precio();
	}

	public static Integer getValoracionProducto(Integer i) {
		return productos.get(i).valoracion();
	}

	public static Integer getNumCategorias() {
		return (int) productos.stream().map(p -> p.categoria).count();
	}

	public static void iniDatos(String fichero) {
		presupuesto = Files2.streamFromFile(fichero).filter(x -> x.contains("Presupuesto"))
				.map(DatosProductos::parseaPresupuesto).findFirst().get();
		productos = Files2.streamFromFile(fichero).skip(2).map(Producto::create).toList();
		String s1 = "Presupuesto: " + presupuesto.toString();
		String2.toConsole("%s\n%s", s1, String2.linea());
		String s2 = productos.stream().map(Producto::toString).collect(Collectors.joining("\n"));
		String2.toConsole("%s\n%s", s2, String2.linea());
	}

	private static Integer parseaPresupuesto(String s) {
		String[] presupuesto = s.split(" = ");
		return Integer.valueOf(presupuesto[1].trim());
	}

	public static void main(String[] args) {
		iniDatos("ficheros/Ejercicio2DatosEntrada2.txt");
	}
}