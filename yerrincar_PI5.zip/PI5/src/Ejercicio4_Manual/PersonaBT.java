package Ejercicio4_Manual;

import Soluciones.SolucionPersonas;

public class PersonaBT {
    private static Double mejorValor;
    private static PersonaState state;
    private static SolucionPersonas solucion;

    public static void search() {
        solucion = null;
        mejorValor = Double.MIN_VALUE; // Estamos maximizando
        state = PersonaState.initial();
        bt_search();
    }

    private static void bt_search() {
        if (state.esTerminal()) {
            Double valorObtenido = state.acumulado;
            if (valorObtenido > mejorValor) { // Estamos maximizando
                mejorValor = valorObtenido;
                solucion = state.getSolucion();
            }
        } else {
            for (Integer a: state.actual.actions()) {
                Double cota = state.cota(a);
                if(cota < mejorValor) continue;
                state.forward(a);
                bt_search();
                state.back();
            }
        }
    }

    public static SolucionPersonas getSolucion() {
        return solucion;
    }
}