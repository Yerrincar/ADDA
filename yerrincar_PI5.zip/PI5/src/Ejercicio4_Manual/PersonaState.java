package Ejercicio4_Manual;

import java.util.List;

import Datos.DatosPersonas;
import Soluciones.SolucionPersonas;
import us.lsi.common.List2;

public class PersonaState {
    PersonaProblem actual;
    Double acumulado;
    List<Integer> acciones;
    List<PersonaProblem> anteriores;

    private PersonaState(PersonaProblem p, Double a, List<Integer> ls1, List<PersonaProblem> ls2) {
        actual = p;
        acumulado = a;
        acciones = ls1;
        anteriores = ls2;
    }

    public static PersonaState initial() {
        PersonaProblem pi = PersonaProblem.initial();
        return of(pi, 0., List2.empty(), List2.empty());
    }

    public static PersonaState of(PersonaProblem prob, Double acum, List<Integer> lsa, List<PersonaProblem> lsp) {
        return new PersonaState(prob, acum, lsa, lsp);
    }

    public void forward(Integer a) {
        if(actual.ultima() != DatosPersonas.getNumPersonas())
            acumulado += DatosPersonas.getAfinidad(actual.ultima(), a);
        acciones.add(a);
        anteriores.add(actual);
        actual = actual.neighbor(a);
    }

    public void back() {
        int last = acciones.size() - 1;
        var prob_ant = anteriores.get(last);
        if(prob_ant.ultima() != DatosPersonas.getNumPersonas()) 
            acumulado -= DatosPersonas.getAfinidad(prob_ant.ultima(), acciones.get(last));
        acciones.remove(last);
        anteriores.remove(last);
        actual = prob_ant;
    }

    public List<Integer> alternativas() {
        return actual.actions();
    }

    public Double cota(Integer a) {
        Integer weight = 0;
        if(actual.ultima() != DatosPersonas.getNumPersonas())
            weight = DatosPersonas.getAfinidad(actual.ultima(), a);
        return acumulado + weight + actual.neighbor(a).heuristic();
    }

    public Boolean esSolucion() {
        return true;
    }

    public boolean esTerminal() {
        return PersonaProblem.goal().test(actual);
    }

    public SolucionPersonas getSolucion() {
        return SolucionPersonas.of(acciones);
    }
}