package Ejercicio4_Manual;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import Datos.DatosPersonas;
import us.lsi.common.List2;
import us.lsi.common.Set2;

public record PersonaProblem(Integer indice, Set<Integer> restante, Integer ultima) {
    public static PersonaProblem initial() {
        Set<Integer> restante = Set2.of();
        for(int i = 0; i < DatosPersonas.getNumPersonas(); i++) {
            restante.add(i);
        }
        return new PersonaProblem(0, restante, DatosPersonas.getNumPersonas());
    }

    public static Predicate<PersonaProblem> goal(){
        return obj -> obj.indice() == DatosPersonas.getNumPersonas();
    }

    public static Predicate<PersonaProblem> goalHasSolution(){
        return obj -> true;
    }

    public List<Integer> actions() {
        List<Integer> alternativas = new ArrayList<>();
        if(indice() == DatosPersonas.getNumPersonas()) {
            return List2.empty();
        } else if(indice() % 2 == 1) {
            Set<String> idiomasPersona = DatosPersonas.getIdiomas(this.ultima);
            Integer edadPersona = DatosPersonas.getEdad(this.ultima);
            String nacionPersona = DatosPersonas.getNacionalidad(this.ultima);
            for(Integer pareja : this.restante) {
                Set<String> idiomasPareja = DatosPersonas.getIdiomas(pareja);
                Integer edadPareja = DatosPersonas.getEdad(pareja);
                String nacionPareja = DatosPersonas.getNacionalidad(pareja);
                Boolean idiomaEnComun = idiomasPareja.stream().anyMatch(idioma -> idiomasPersona.contains(idioma));
                Integer diferenciaEdad = Math.abs(edadPersona - edadPareja);
                Boolean distintaNacionalidad = !nacionPersona.equals(nacionPareja);
                if(idiomaEnComun && diferenciaEdad <= 5 && distintaNacionalidad) {
                    alternativas.add(pareja);
                }
            }
            return alternativas;
        } else {
            return List2.of(this.restante.stream().findFirst().get());
        }
    }

    public PersonaProblem neighbor(Integer a) {
        Integer index = this.indice + 1;
        Set<Integer> res = Set2.copy(this.restante);
        if(index % 2 == 0) {
            Integer ult = DatosPersonas.getNumPersonas();
            res.remove(a);
            return new PersonaProblem(index, res, ult);
        } else {
            Integer ult = a;
            res.remove(ult);
            return new PersonaProblem(index, res, ult);
        }
    }

    public Double heuristic() {
        if(this.ultima() == DatosPersonas.getNumPersonas())
            return 0.;
        else return IntStream.range(this.ultima(), DatosPersonas.getNumPersonas())
            .mapToDouble(i -> mejorOpcion(i, this.restante().stream().toList())).sum();
    }

    private static Double mejorOpcion(Integer i, List<Integer> restante) {
        return restante.stream()
            .filter(j -> j != i)
            .mapToDouble(j -> DatosPersonas.getAfinidad(i, j)).max()
            .orElse(0);
    }
}