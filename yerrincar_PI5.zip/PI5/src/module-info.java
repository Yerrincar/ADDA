/**
 * 
 */
/**
 * 
 */
module PI5 {	
	requires transitive grafos;
	requires transitive partecomun;
	requires org.jgrapht.core;
}