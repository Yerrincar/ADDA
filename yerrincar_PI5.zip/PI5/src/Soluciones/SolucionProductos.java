package Soluciones;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.jgrapht.GraphPath;

import Datos.DatosProductos;
import Ejercicio2.ProductosEdge;
import Ejercicio2.ProductosVertex;

public record SolucionProductos(Double precioTotal, List<Integer> productos, Integer acumValoracion) implements Comparable<SolucionProductos> {

    public static SolucionProductos of(GraphPath<ProductosVertex, ProductosEdge> path) {
        List<Integer> la = path.getEdgeList().stream().map(e -> e.action()).toList();
        return SolucionProductos.of(la);
    }

    public static SolucionProductos of(List<Integer> value) {
        List<Integer> pS = new ArrayList<>();
        Double pT = 0.;
        Integer aV = 0;
        for (int i = 0; i < value.size(); i++) {
            if (value.get(i) == 1) {
                pS.add(i);
                pT += DatosProductos.getPrecioProducto(i);
                aV += DatosProductos.getValoracionProducto(i) - 3;
            }
        }
        return new SolucionProductos(pT, pS, aV);
    }

    @Override
    public int compareTo(SolucionProductos o) {
        return this.precioTotal().compareTo(o.precioTotal());
    }

    @Override
    public String toString() {
        String s = productos.stream().map(p -> "Producto" + p)
                .collect(Collectors.joining(", ", "{", "} \n Precio Total:" + precioTotal));
        return s;
    }
}