package Soluciones;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jgrapht.GraphPath;

import Datos.DatosAgricultor;
import Ejercicio1.HuertosEdge;
import Ejercicio1.HuertosVertex;
import us.lsi.common.List2;

public record SolucionAgricultor(Double weight, Map<Integer, List<Integer>> map) implements Comparable<SolucionAgricultor>{

	public static SolucionAgricultor of(GraphPath<HuertosVertex, HuertosEdge> camino) {
        List<Integer> list = camino.getEdgeList().stream().map(x -> x.action()).toList();
        return SolucionAgricultor.of(list);
    }
    
	public static SolucionAgricultor of(List<Integer> value) {
		Map<Integer, List<Integer>> map = new HashMap<>();
		Double weight = (double) value.stream().filter(x -> x != DatosAgricultor.getNumHuertos()).count();
		Integer cont = 0;
		for (Integer i: value) {
			if (i < DatosAgricultor.getNumHuertos()) {
				if (map.containsKey(i)) {
					map.get(i).add(cont);
				} else {
					List<Integer> listaReparto = List2.empty();
					listaReparto.add(cont);
					map.put(i, listaReparto);
				}
			}
			cont++;
		}
		return new SolucionAgricultor(weight, map);
	}

	@Override
	public int compareTo(SolucionAgricultor o) {
		// TODO Auto-generated method stub
		return this.weight().compareTo(o.weight());
	}
}