package Soluciones;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.jgrapht.GraphPath;

import Datos.DatosPersonas;
import Ejercicio4.PersonaEdge;
import Ejercicio4.PersonaVertex;
import us.lsi.common.IntPair;

public record SolucionPersonas(Integer peso, List<IntPair> parejas) implements Comparable<SolucionPersonas> {
    public static SolucionPersonas of(GraphPath<PersonaVertex, PersonaEdge> path) {
        List<Integer> la = path.getEdgeList().stream().map(e -> e.action()).toList();
        return SolucionPersonas.of(la);
    }

    public static SolucionPersonas of(List<Integer> value) {
        List<IntPair> p = new ArrayList<>();
        Integer afT = 0;
        Boolean b = true;
        Boolean b2 = true;
        Boolean b3 = true;
        List<Integer> cr = new ArrayList<>(value);
        if(cr.size() % 2 == 1) cr.remove(cr.size() - 1);
        for(int i = 0; i < cr.size() - 1; i+=2) {
            IntPair pareja = IntPair.of(cr.get(i), cr.get(i+1));
            p.add(pareja);
            afT += DatosPersonas.getAfinidad(cr.get(i), cr.get(i+1));
        }
        for(IntPair par:p) {
            Set<String> intersection = DatosPersonas.getIdiomas(par.first());
            intersection.retainAll(DatosPersonas.getIdiomas(par.second()));
            b = b && !intersection.isEmpty();
            b2 = b2 && Math.abs(DatosPersonas.getEdad(par.first()) - DatosPersonas.getEdad(par.second())) <= 5;
            b3 = b3 && !DatosPersonas.getNacionalidad(par.first()).equals(DatosPersonas.getNacionalidad(par.second()));
        }
        System.out.println(b + " " + b2 + " " + b3);
        return new SolucionPersonas(afT, p);
    }

    @Override
    public String toString() {
        return String.format("Relacion de parejas: \n%s\nSuma de afinidades: %d", parejas, peso);
    }

    @Override
    public int compareTo(SolucionPersonas o) {
        return this.peso.compareTo(o.peso);
    }
}