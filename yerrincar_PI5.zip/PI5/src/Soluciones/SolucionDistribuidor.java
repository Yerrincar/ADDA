package Soluciones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jgrapht.GraphPath;

import Datos.DatosDistribuidor;
import Ejercicio3.DistribuidorEdge;
import Ejercicio3.DistribuidorVertex;

public record SolucionDistribuidor(Double peso, Map<Integer, List<Integer>> reparto)
		implements Comparable<SolucionDistribuidor> {
	public static SolucionDistribuidor of(GraphPath<DistribuidorVertex, DistribuidorEdge> path) {
		List<Integer> la = path.getEdgeList().stream().map(e -> e.action()).toList();
		return SolucionDistribuidor.of(la);
	}

	public static SolucionDistribuidor of(List<Integer> value) {
		Double costeAcum = 0.;
		Map<Integer, List<Integer>> s = new HashMap<>();
		for (int x = 0; x < value.size(); x++) {
			Integer indiceDestino = x % DatosDistribuidor.getNumDestinos();
			Integer indiceProducto = x / DatosDistribuidor.getNumDestinos();
			if (s.containsKey(indiceProducto)) {
				s.get(indiceProducto).add(value.get(x));
			} else {
				List<Integer> ls = new ArrayList<>();
				ls.add(value.get(x));
				s.put(indiceProducto, ls);
			}
			costeAcum += value.get(x) * DatosDistribuidor.getCoste(indiceProducto, indiceDestino);
		}
		return new SolucionDistribuidor(costeAcum, s);
	}

	@Override
	public int compareTo(SolucionDistribuidor o) {
		return this.peso().compareTo(o.peso());
	}

	@Override
	public String toString() {
		String s = this.reparto().entrySet().stream()
				.map(e -> "Cantidad de producto" + e.getKey() + " en el destino" + e.getValue() + ": "
						+ e.getValue().stream().mapToInt(Integer::intValue).sum())
				.collect(Collectors.joining("\n", "Productos enviados a destinos: \n",
						"\n Coste total: " + this.peso() + " \n"));
		return s;
	}
}