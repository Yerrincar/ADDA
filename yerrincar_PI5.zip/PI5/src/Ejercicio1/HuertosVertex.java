package Ejercicio1;

import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import Datos.DatosAgricultor;
import us.lsi.common.IntegerSet;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record HuertosVertex(Integer index, List<IntegerSet> reparto, List<Integer> metrosDisponibles) implements VirtualVertex<HuertosVertex, HuertosEdge, Integer> {
	
	public static HuertosVertex initial() {
		List<IntegerSet> reparto = List2.empty();
		List<Integer> metrosDisp = List2.empty();
		for (int i = 0; i < DatosAgricultor.getNumHuertos(); i++) {
			metrosDisp.add(DatosAgricultor.getHuertos().get(i));
			reparto.add(IntegerSet.empty());
		}
		return new HuertosVertex(0, reparto, metrosDisp);
	}
	
	public List<Integer> actions() {
		List<Integer> actions = List2.of(DatosAgricultor.getNumHuertos());
		if (index() >= DatosAgricultor.getNumVariedades()) {
			return List2.empty();
		} else {
			for (int i = 0; i < DatosAgricultor.getNumHuertos(); i++) {
				Set<Integer> huerto = reparto.get(i);
				Integer mRest = metrosDisponibles.get(i) - DatosAgricultor.getVariedadI(index);
				if(mRest >= 0 && huerto.stream().noneMatch(x -> DatosAgricultor.getIncompatibilidad(x, index) == 1)) {
					actions.add(i);
				}
			}
			return actions;
		}

    }
	
	public HuertosVertex neighbor(Integer a) {
        List<IntegerSet> reparto = List2.copy(this.reparto);
        List<Integer> disp = List2.copy(this.metrosDisponibles);
        
        if(a != DatosAgricultor.getNumHuertos()) {
        	Integer diff = metrosDisponibles().get(a) - DatosAgricultor.getVariedadI(this.index);
        	metrosDisponibles.set(a, diff);
        	IntegerSet copia = IntegerSet.copy(this.reparto.get(a));
        	copia.add(index());
        	reparto.set(a, copia);
		}
		return new HuertosVertex(this.index + 1, reparto, disp);
    }
	
	@Override
	public HuertosEdge edge(Integer a) {
        return HuertosEdge.of(this, neighbor(a), a);
    }
	
	public static Predicate<HuertosVertex> goal() {
        return x -> x.index() == DatosAgricultor.getNumVariedades();
    }
    
	public static Predicate<HuertosVertex> goalHasSolution() { 
        return x -> true;
	}
	
	public String toGraph() {
		return String.format("%d, %s, %s", this.index, this.reparto, this.metrosDisponibles);
	}
	
	public static void main(String[] args) {
		
		DatosAgricultor.iniDatos("Ficheros/Ejercicio1DatosEntrada1.txt");
		System.out.println(initial());
	}

	
}