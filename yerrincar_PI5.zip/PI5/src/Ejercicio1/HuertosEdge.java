package Ejercicio1;

import Datos.DatosAgricultor;
import us.lsi.graphs.virtual.SimpleEdgeAction;

public record HuertosEdge(HuertosVertex source, HuertosVertex target, Integer action, Double weight) implements SimpleEdgeAction<HuertosVertex, Integer> {
    
    public static HuertosEdge of(HuertosVertex source, HuertosVertex target, Integer action) {
        Double peso = 0.;
		if (action != DatosAgricultor.getNumHuertos()) {
			peso=1.;
		}
        return new HuertosEdge(source, target, action, peso);
    }
}