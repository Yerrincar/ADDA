package Ejercicio1;

import java.util.Set;
import java.util.function.Predicate;

import Datos.DatosAgricultor;

public class HuertosHeuristic {

	public static Double heuristic(HuertosVertex v1, Predicate<HuertosVertex> goal, HuertosVertex v2) {
		Double res = 0.;
			for (int i = v1.index(); i < DatosAgricultor.getNumVariedades(); i++) {
				for (int j = 0; j < DatosAgricultor.getNumHuertos(); j++) {
					Set<Integer> huerto = v1.reparto().get(j);
					Integer metrosRestantes = v1.metrosDisponibles().get(j) - DatosAgricultor.getVariedadI(i);
					Integer var = i;
					if (metrosRestantes >= 0
							&& huerto.stream().noneMatch(x -> DatosAgricultor.getIncompatibilidad(var, x) == 1)) {
						res += 1.;
					}
				}
			}
		return res;
	}
}