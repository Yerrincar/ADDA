/**
 * 
 */
/**
 * 
 */
module PI4 {
	
	exports Ejercicio_1;
	
	requires transitive datos_compartidos;
	requires transitive ejemplos_algoritmos;
	requires transitive ejemplos_parte_comun;
	requires transitive geneticos;
	requires transitive grafos;
	requires transitive partecomun;
	requires transitive solve;
}