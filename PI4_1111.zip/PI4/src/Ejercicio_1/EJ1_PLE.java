package Ejercicio_1;

import java.io.IOException;
import java.util.Locale;

import Datos.DatosAgricultor;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class EJ1_PLE {
		
		public static void model_ejercicio1() {
			
			for(int k = 1; k <= 3; k++) {
				DatosAgricultor.iniDatos("Ficheros/Ejercicio1DatosEntrada" + k + ".txt");
				
				try {
					AuxGrammar.generate(DatosAgricultor.class, "lsi_models/Ejercicio1.lsi", "gurobi_models/Ejercicio1_" + k + ".lp");
					GurobiSolution solution = GurobiLp.gurobi("gurobi_models/Ejercicio1_" + k + ".lp");
					Locale.setDefault(Locale.of("en", "US"));
					System.out.println(solution.toString((s, d) -> d > 0.) + "\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		public static void main(String[] args) {
			model_ejercicio1();
		}
	}
