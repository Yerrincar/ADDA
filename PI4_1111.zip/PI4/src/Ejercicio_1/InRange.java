package Ejercicio_1;

import java.util.List;

import Datos.DatosAgricultor;
import Soluciones.SolucionAgricultor;
import us.lsi.ag.RangeIntegerData;



public class InRange implements RangeIntegerData<SolucionAgricultor>{

	public InRange(String file) {
		DatosAgricultor.iniDatos(file);
	}

	@Override
	public Integer max(Integer i) {
		return DatosAgricultor.getMaximoHuerto(i) + 1;
	}

	@Override
	public Integer min(Integer i) {
		return 0;
	}

	@Override
	public Integer size() {
		return DatosAgricultor.getNumVariedades();
	}

	@Override
	public Double fitnessFunction(List<Integer> value) {
	    double goal = 0, error = 0;
	    int[] v = new int[DatosAgricultor.getNumVariedades()];
	    for(int i=0; i<value.size(); i++) {
	        int index = value.get(i);
	        if (index < DatosAgricultor.getNumVariedades() && i < DatosAgricultor.getNumHuertos()) {
	            v[index]++;
	            int a = DatosAgricultor.getVarCompatibilidad(i, index)? 1:0;
	            if(a>0)
	                goal+=a;
	            else
	                error ++;
	        } else {
	            error++;
	        }
	    }
	    for(int e: v) {
	        error+= e!=DatosAgricultor.getNumVariedades()?1:0;
	    }
	    return goal -10000*error;
	}
	@Override
	public SolucionAgricultor solucion(List<Integer> value) {
		return SolucionAgricultor.Range(value);
	}
	
	
}
