package Datos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import us.lsi.common.Files2;
 		
public class DatosAgricultor {

	public static List<Integer> huertos;
	public static List<Variedad> variedades;

	public record Variedad(Integer id, Integer metros, List<Boolean> compatibilidad) {

		public static Integer contador;
		public static Variedad create(String linea) {
			List<Boolean> comp = new ArrayList<>();
			for (int i = 0; i < huertos.size(); i++) {
				comp.add(true);

			}
			String[] var = linea.split(";");
			Integer metros = Integer.parseInt(var[0].split("=")[1].replace(";", "").trim());
			String[] incompatibilidad = var[1].split("=")[1].replace("V", "").trim().split(",");
			for (int i = 0; i < incompatibilidad.length; i++) {
				Integer variedad = Integer.parseInt(incompatibilidad[i].trim());
				if(variedad<huertos.size()) {
				comp.set(variedad, false);
				}
			}
			return new Variedad(contador++, metros, new ArrayList<>(comp));
		}
	}

	public static void iniDatos(String file) {
		Variedad.contador = 0;

		List<String> lines = Files2.linesFromFile(file);
		Integer posicion = lines.indexOf("// VARIEDADES");
		List<String> huertosData = lines.subList(1, posicion);
		List<String> varData = lines.subList(posicion + 1, lines.size());

		List<Integer> auxiliar = new ArrayList<>();
		for (int j = 0; j < huertosData.size(); j++) {
			Integer value = Integer.parseInt(huertosData.get(j).split("=")[1].replace(";", "").trim());
			auxiliar.add(value);
		}
		huertos = new ArrayList<>(auxiliar);
		variedades = new ArrayList<>();

		for (int j = 0; j < varData.size(); j++) {
			variedades.add(Variedad.create(varData.get(j)));
		}
		toConsole();
	}
	public static void main(String[] args) {
		for(int i=0; i< 3; i++) {
			System.out.println("Fichero de entrada: " + (i+1));
			iniDatos("ficheros/Ejercicio1DatosEntrada" + (i+1) + ".txt");
			System.out.println("\n");
		}
	}

	public static Integer getNumHuertos() {
		return huertos.size();
	}

	public static Integer getMetrosHuerto(Integer j) {
		return huertos.get(j);
	}

	public static Integer getNumVariedades() {
		return variedades.size();
	}

	public static List<Variedad> getVariedades() {
		return new ArrayList<>(variedades);
	}

	public static Integer getMetrosVar(Integer j) {
		return variedades.get(j).metros();
	}

	public static Boolean getVarCompatibilidad(Integer j, Integer i) {
		return variedades.get(i).compatibilidad().get(j);
	}

	public static Integer getMaximoHuerto(Integer i) {
		List<Integer> lista = new ArrayList<>();

		for (int j = 0; j < huertos.size(); j++) {
			if (getVarCompatibilidad(j, i)) {
				lista.add(getMetrosHuerto(j) / getMetrosVar(i));
			}
		}
		lista.sort(Comparator.naturalOrder());
		return lista.isEmpty() ? 0 : lista.get(0);
	}

	private static void toConsole() {
		System.out.println(
				"Variedades disponibles: " + variedades + "\nMetros cuadrados disponibles por huerto: " + huertos + "NumHuertos: " + getNumHuertos());

	}

	

}
