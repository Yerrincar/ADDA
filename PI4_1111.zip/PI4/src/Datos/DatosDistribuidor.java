package Datos;

import java.util.ArrayList;
import java.util.List;

import us.lsi.common.Files2;

public class DatosDistribuidor {

    public static List<Destino> destinos;
    public static List<Producto> productos;

    public record Destino(Integer id, Integer demandaMinima) {

        public static Integer contador;
        public static Destino create(String linea) {
            String[] dest = linea.split("=");
            Integer id = Integer.parseInt(dest[0].replace("D", "").trim());
            Integer demandaMinima = Integer.parseInt(dest[1].replace(";", "").trim());
            return new Destino(id, demandaMinima);
        }
    }

    public record Producto(Integer id, Integer unidades, List<Integer> costeAlmacenamiento) {

        public static Integer contador;
        public static Producto create(String linea) {
            String[] prod = linea.split(";");
            Integer id = Integer.parseInt(prod[0].replace("P", "").split("->")[0].trim());
            Integer unidades = Integer.parseInt(prod[0].split("=")[1].trim());
            List<Integer> costeAlmacenamiento = new ArrayList<>();
            String[] costes = prod[1].split("=")[1].replace("(", "").replace(")", "").split(",");
            for (String coste : costes) {
                costeAlmacenamiento.add(Integer.parseInt(coste.split(":")[1].trim()));
            }
            return new Producto(id, unidades, costeAlmacenamiento);
        }
    }

    public static void iniDatos(String file) {
        Destino.contador = 0;
        Producto.contador = 0;

        List<String> lines = Files2.linesFromFile(file);
        Integer posicion = lines.indexOf("// PRODUCTOS");
        List<String> destData = lines.subList(1, posicion);
        List<String> prodData = lines.subList(posicion + 1, lines.size());
        
        List<Integer> auxiliar = new ArrayList<>();
		for (int j = 0; j < destData.size(); j++) {
			Integer value = Integer.parseInt(destData.get(j).split("=")[1].replace(";", "").trim());
			auxiliar.add(value);
		}
        destinos = new ArrayList<>();
        for (int j = 0; j < destData.size(); j++) {
            destinos.add(Destino.create(destData.get(j)));
        }

        productos = new ArrayList<>();
        for (int j = 0; j < prodData.size(); j++) {
            productos.add(Producto.create(prodData.get(j)));
        }
        toConsole();
    }

    public static void main(String[] args) {
        for(int i=0; i< 3; i++) {
            System.out.println("Fichero de entrada: " + (i+1));
            iniDatos("ficheros/Ejercicio3DatosEntrada" + (i+1) + ".txt");
            System.out.println("\n");
        }
    }

    public static Integer getNumDestinos() {
        return destinos.size();
    }

    public static Integer getDemandaMinimaDestino(Integer j) {
        return destinos.get(j).demandaMinima();
    }

    public static Integer getNumProductos() {
        return productos.size();
    }

    public static Integer getUnidadesProducto(Integer j) {
        return productos.get(j).unidades();
    }

    public static Integer getCosteAlmacenamientoProductoDestino(Integer j, Integer i) {
        return productos.get(i).costeAlmacenamiento().get(j);
    }

    private static void toConsole() {
        System.out.println(
                "Destinos disponibles: " + destinos + "\nProductos disponibles: " + productos);
    }
}