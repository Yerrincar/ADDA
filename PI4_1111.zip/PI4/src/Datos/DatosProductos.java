package Datos;

import java.util.ArrayList;
import java.util.List;

import us.lsi.common.Files2;

public class DatosProductos {

    public static Integer presupuesto;
    public static List<Producto> productos;

    public record Producto(Integer id, Integer precio, Integer categoria, Integer valoracion) {

        public static Integer contador;
        public static Producto create(String linea) {
            String[] prod = linea.split(":");
            Integer id = Integer.parseInt(prod[0].trim());
            Integer precio = Integer.parseInt(prod[1].trim());
            Integer categoria = Integer.parseInt(prod[2].trim());
            Integer valoracion = Integer.parseInt(prod[3].trim());
            return new Producto(id, precio, categoria, valoracion);
        }
    }

    public static void iniDatos(String file) {
        Producto.contador = 0;

        List<String> lines = Files2.linesFromFile(file);
        presupuesto = Integer.parseInt(lines.get(0).split("=")[1].trim());
        List<String> prodData = lines.subList(2, lines.size());

        productos = new ArrayList<>();

        for (int j = 0; j < prodData.size(); j++) {
            productos.add(Producto.create(prodData.get(j)));
        }
        toConsole();
    }

    public static void main(String[] args) {
        for(int i=0; i< 3; i++) {
            System.out.println("Fichero de entrada: " + (i+1));
            iniDatos("ficheros/Ejercicio2DatosEntrada" + (i+1) + ".txt");
            System.out.println("\n");
        }
    }

    public static Integer getNumProductos() {
        return productos.size();
    }

    public static Integer getPrecioProducto(Integer j) {
        return productos.get(j).precio();
    }

    public static Integer getCategoriaProducto(Integer j) {
        return productos.get(j).categoria();
    }

    public static Integer getValoracionProducto(Integer j) {
        return productos.get(j).valoracion();
    }

    private static void toConsole() {
        System.out.println(
                "Productos disponibles: " + productos + "\nPresupuesto disponible: " + presupuesto);
    }
}