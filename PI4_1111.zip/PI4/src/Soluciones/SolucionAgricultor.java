package Soluciones;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import Datos.DatosAgricultor;
import Datos.DatosAgricultor.Variedad;

public class SolucionAgricultor {

	private Integer variedades;
	private List<Variedad> soluciones;
	private List<Integer> solucion;
	
	public static SolucionAgricultor Range(List<Integer> value) {
		return new SolucionAgricultor(value);
	}
	
	private SolucionAgricultor() {
		
		variedades = 0;
		soluciones = new ArrayList<>();
		solucion = new ArrayList<>();
	}
	
	private SolucionAgricultor(List<Integer> l) {
		
		variedades = 0;
		soluciones = new ArrayList<>();
		solucion = new ArrayList<>();
		for(int i = 0; i < l.size(); i++) {
			if(l.get(i) > 0) {
				variedades++;
				soluciones.add(DatosAgricultor.getVariedades().get(i));
				solucion.add(l.get(i));
			}
		}
	}
	 
	public static SolucionAgricultor empty() {
		return new SolucionAgricultor();
	}
	
	public String toString() {
		
		String s = soluciones.stream().map(v -> "V"+ v.id() + ": Huerto " + solucion.get(soluciones.indexOf(v)))
				.collect(Collectors.joining("\n",
						"Reparto de verduras y huerto en el que es plantada cada una de ellas (si procede):\n","\n"));
		return String.format("%sVariedades cultivadas: %d",s, variedades);
	}
}