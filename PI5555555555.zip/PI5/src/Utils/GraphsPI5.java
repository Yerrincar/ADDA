package Utils;

import Ejercicio1.HuertosEdge;
import Ejercicio1.HuertosHeuristic;
import Ejercicio1.HuertosVertex;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.EGraph.Type;
import us.lsi.path.EGraphPath.PathType;

public class GraphsPI5 {

    public static EGraph<HuertosVertex, HuertosEdge> huertosGraph(HuertosVertex v_inicial) {
        return EGraph.virtual(v_inicial, PathType.Sum, Type.Max)
                .edgeWeight(HuertosEdge::weight)
                .endVertex(v_inicial)
                .heuristic(HuertosHeuristic::heuristic).build();
    }

    public static EGraph<HuertosVertex, HuertosEdge> greedyHuertosGraph(HuertosVertex v_inicial) {
        return EGraph.virtual(v_inicial, PathType.Sum, Type.Max)
                .edgeWeight(HuertosEdge::weight)
                .endVertex(v_inicial)
                .heuristic(HuertosHeuristic::heuristic).build();
    }
}