/**
 * 
 */
/**
 * 
 */
module PI5 {
	
	exports Ejercicio1;
	
	requires transitive datos_compartidos;
	requires transitive ejemplos_algoritmos;
	requires transitive ejemplos_parte_comun;
	requires transitive geneticos;
	requires transitive grafos;
	requires transitive partecomun;
	requires transitive solve;
}