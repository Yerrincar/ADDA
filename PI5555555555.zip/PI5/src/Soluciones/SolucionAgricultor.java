package Soluciones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jgrapht.GraphPath;

import Ejercicio1.HuertosEdge;
import Ejercicio1.HuertosVertex;

public class SolucionAgricultor {
    
    public static SolucionAgricultor of(GraphPath<HuertosVertex, HuertosEdge> path) {
        List<Integer> list = path.getEdgeList().stream().map(t -> t.action()).toList();
        SolucionAgricultor resultado = new SolucionAgricultor(list);
        resultado.path = list;
        return resultado;
    }
    
    private List<Integer> path;
    private List<Map<String, Integer>> solution;
    private Integer variedadesSembradas;
    
    private SolucionAgricultor() {
        variedadesSembradas = 0;
        solution = new ArrayList<>();
    }
    
    private SolucionAgricultor(List<Integer> list) {
        variedadesSembradas = 0;
        solution = new ArrayList<>();
        
        for(int k = 0; k < list.size(); k++) {
            Map<String, Integer> mapa = new HashMap<>();
            if(list.get(k) > 0) {
                variedadesSembradas++;
                Integer e = list.get(k);
                mapa.put("Huerto " + (k+1), e);
                solution.add(mapa);
            }
        }
    }
    
    public static SolucionAgricultor empty() {
        return new SolucionAgricultor();
    }
    
    public String toString() {
        String st = String.format("\nVariedades sembradas = %s", variedadesSembradas);
        String s = path == null ? st : String.format("%s\nPath de la solucion: %s", st, path);
        return s;
    }
}