package Ejercicio1;

import java.util.List;
import java.util.stream.IntStream;

import Datos.DatosAgricultor;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.VirtualVertex;

public record HuertosVertex(Integer index, List<Integer> remaining) implements VirtualVertex<HuertosVertex, HuertosEdge, Integer> {
    
    public static HuertosVertex of(Integer index, List<Integer> remaining) {
        return new HuertosVertex(index, remaining);
    }
    
    public static HuertosVertex initial() {
        List<Integer> remaining = DatosAgricultor.getHuertos();
        return of(0, remaining);
    }
    
    private Integer opciones(Integer index) {
        Integer res = 0;
        if (index >= initial().remaining().size()) {
            return res;
        }
        Integer elemento = DatosAgricultor.getVariedadI(index);
        List<Integer> rest2 = initial().remaining();
        while( rest2.get(index) >= elemento ) {
            res++;
            rest2.set(index, rest2.get(index) - elemento);
        }
        return res;
    }
    public List<Integer> actions() {
        List<Integer> alternativas = List2.empty();
        if (index < DatosAgricultor.getNumVariedades()) {
            if (index == DatosAgricultor.getNumVariedades() - 1) {
                if( opciones(index) == 0 ) {
                    alternativas = List2.of(0);
                } else {
                    alternativas = List2.of(opciones(index));
                }
            } else {
                alternativas = List2.rangeList(0, opciones(index) + 1);
            }
        }
        return alternativas;
    }
  

    public HuertosVertex neighbor(Integer a) {
        Integer elemento = DatosAgricultor.getVariedadI(index);
        List<Integer> rest2 = IntStream.range(0, remaining.size()).mapToObj(i -> remaining.get(i) - (i == index ? elemento * a : 0)).toList();
        return of(index + 1, rest2);
    }
    
    public HuertosEdge edge(Integer a) {
        return HuertosEdge.of(this, neighbor(a), a);
    }
    
    public HuertosEdge greedyEdge() {
        HuertosEdge res = edge(opciones(index));
        return res;
    }
    
    @Override
    public String toString() {
        return String.format(index.toString() + " , " + remaining.toString());
    }
    
    @Override
    public Boolean goal() {
        return this.index() == DatosAgricultor.getNumVariedades();
    }
    
	@Override
	public Boolean goalHasSolution() { 
        return this.index() == DatosAgricultor.getNumVariedades();
		
	}

	@Override
	public Integer greedyAction() {
		Integer res = opciones(index);
		return res;
	}
}