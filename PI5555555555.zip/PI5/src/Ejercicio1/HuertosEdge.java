package Ejercicio1;

import Datos.DatosAgricultor;
import us.lsi.graphs.virtual.SimpleEdgeAction;

public record HuertosEdge(HuertosVertex source, HuertosVertex target, Integer action, Double weight) implements SimpleEdgeAction<HuertosVertex, Integer> {
    
    public static HuertosEdge of(HuertosVertex source, HuertosVertex target, Integer action) {
        Double peso = action * Double.valueOf(DatosAgricultor.getVariedadI(source.index()));
        return new HuertosEdge(source, target, action, peso);
    }
    
    @Override
    public String toString() {
        return String.format("%s, %s", action, weight);
    }
    
}