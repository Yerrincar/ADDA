package Ejercicio1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import Datos.DatosAgricultor;
import us.lsi.common.List2;

public class HuertosHeuristic {

	public static Double heuristic(HuertosVertex v1, Predicate<HuertosVertex> goal, HuertosVertex v2) {
		if (!goal.test(v1)) {
			if (v1.index() >= DatosAgricultor.getNumHuertos()) {
				return 0.;
			}
			Integer n = DatosAgricultor.getHuertoI(v1.index());
			List<Integer> list = List2.rangeList(0, n + 1);
			Map<Integer, List<Integer>> mapa = new HashMap<>();
			for (Integer s : list) {
				List<Integer> resultado = new ArrayList<>();
				for (int k = 0; k < DatosAgricultor.getNumHuertos(); k++) {
					if (k >= v1.remaining().size()) {
						break;
					}
					Integer m = (int) (v1.remaining().get(k) - s * DatosAgricultor.getIncompatibilidad(v1.index(), k));
					resultado.add(m);
				}
				mapa.put(s, resultado);
			}
			List<Double> ben = new ArrayList<>();
			for (Integer t : list) {
				if (!mapa.containsKey(t)) {
					continue;
				}
				List<Integer> result = mapa.get(t);
				Double beneficio = (double) t;
				List<Integer> list2 = List2.rangeList(v1.index() + 1, DatosAgricultor.getNumVariedades());
				Double beneficio2 = list2.stream().filter(z -> z < DatosAgricultor.getNumHuertos())
						.mapToDouble(z -> DatosAgricultor.getVariedadI(z) * DatosAgricultor.getHuertoI(z)).sum();
				ben.add(beneficio + beneficio2);
			}
			Double maximo = ben.stream().mapToDouble(g -> g).max().orElse(0);
			return maximo;
		} else {
			return 0.;
		}
	}
}