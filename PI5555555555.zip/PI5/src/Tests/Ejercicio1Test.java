package Tests;

import java.util.List;
import java.util.function.Predicate;

import org.jgrapht.GraphPath;

import Datos.DatosAgricultor;
import Ejercicio1.HuertosVertex;
import Soluciones.SolucionAgricultor;
import Utils.GraphsPI5;
import Utils.TestsPI5;

public class Ejercicio1Test {
    
    public static void main(String[] args) {
        List.of(1,2,3).forEach(num_test -> {
            TestsPI5.iniTest("Ejercicio1DatosEntrada", num_test, DatosAgricultor::iniDatos);
            System.out.println("*************************************************FICHERO " + num_test + "******************************************");
            
            HuertosVertex v_inicial = HuertosVertex.initial();

            
            var gp = (GraphPath) TestsPI5.testGreedy(GraphsPI5.greedyHuertosGraph(v_inicial));
            TestsPI5.toConsole("Voraz", gp, SolucionAgricultor::of);	
            
            var path = (GraphPath) TestsPI5.testAStar(GraphsPI5.huertosGraph(v_inicial), gp);
            TestsPI5.toConsole("A*", path, SolucionAgricultor::of);
            
            path = (GraphPath) TestsPI5.testPDR(GraphsPI5.huertosGraph(v_inicial), gp);
            TestsPI5.toConsole("PDR", path, SolucionAgricultor::of);
            
            path = (GraphPath) TestsPI5.testBT(GraphsPI5.huertosGraph(v_inicial), gp);
            TestsPI5.toConsole("BT", path, SolucionAgricultor::of);
        
            
            TestsPI5.line("*");
            
        });
    }
}